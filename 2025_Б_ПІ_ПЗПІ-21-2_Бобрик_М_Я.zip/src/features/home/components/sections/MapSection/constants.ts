export const addresses: { name: string; address: string }[] = [
  {
    name: 'Притулок для тварин "Сіріус"',
    address: 'Вулиця Покровська, 6, смт Федорівка, Київська область',
  },
  {
    name: 'Притулок "SOS Animals Ukraine"',
    address: 'Вулиця Обухівська, 123, Київ',
  },
  {
    name: 'Домівка врятованих тварин',
    address: 'Вулиця Довбуша, 24, Львів',
  },
  {
    name: 'ЛКП "Лев"',
    address: 'Вулиця Промислова, 56, Львів',
  },
];
