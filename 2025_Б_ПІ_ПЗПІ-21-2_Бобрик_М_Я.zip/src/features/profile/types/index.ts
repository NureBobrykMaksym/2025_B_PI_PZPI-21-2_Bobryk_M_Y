export type User = {
  id: string;
  email: string;
  role: 'User' | 'Admin';
  exp: number;
};
