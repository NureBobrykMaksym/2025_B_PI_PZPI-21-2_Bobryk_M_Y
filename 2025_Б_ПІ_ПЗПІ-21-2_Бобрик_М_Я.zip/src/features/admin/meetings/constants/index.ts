export const meetingStatuses = [
  {
    value: 0,
    title: 'Скасована',
  },
  {
    value: 1,
    title: 'Запланована',
  },
  {
    value: 2,
    title: 'Завершена',
  },
];
