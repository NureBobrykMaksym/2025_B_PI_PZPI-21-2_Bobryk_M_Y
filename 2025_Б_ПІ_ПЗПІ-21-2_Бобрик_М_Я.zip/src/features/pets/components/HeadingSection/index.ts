export { HeadingSection } from './HeadingSection';
