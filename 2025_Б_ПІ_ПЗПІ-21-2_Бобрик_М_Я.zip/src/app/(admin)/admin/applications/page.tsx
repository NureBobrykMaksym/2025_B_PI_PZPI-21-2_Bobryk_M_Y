'use client';

import { ApplicationsModule } from '@/features/admin/applications/components/ApplicationsModule';

export default function ApplicationsPage() {
  return <ApplicationsModule />;
}
