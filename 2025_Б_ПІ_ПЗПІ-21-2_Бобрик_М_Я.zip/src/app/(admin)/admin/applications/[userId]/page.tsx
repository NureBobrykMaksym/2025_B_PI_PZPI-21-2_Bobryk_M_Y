'use client';

import { ApplicationSurveyModule } from '@/features/admin/applications/components/ApplicationSurveyModule';

export default function ApplicationSurveyPage() {
  return <ApplicationSurveyModule />;
}
