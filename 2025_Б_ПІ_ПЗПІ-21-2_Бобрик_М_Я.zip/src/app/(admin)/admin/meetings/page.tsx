'use client';

import { MeetingsModule } from '@/features/admin/meetings/components/MeetingsModule';

export default function MeetingsPage() {
  return <MeetingsModule />;
}
