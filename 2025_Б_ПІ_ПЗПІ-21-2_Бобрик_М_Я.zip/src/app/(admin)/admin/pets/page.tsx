'use client';

import { PetsModule } from '@/features/admin/pets/components/PetsModule/PetsModule';

export default function PetsPage() {
  return <PetsModule />;
}
