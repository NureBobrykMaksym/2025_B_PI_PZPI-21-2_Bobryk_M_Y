Project Structure:

```
diploma_fe
├── src
│   ├── app
│   ├── components
│   ├── config
│   ├── features
│   ├── hooks
│   ├── lib
│   ├── stores
│   ├── styles
│   ├── types
│   └── utils
├── .env.example
├── .eslintrc.json
├── .gitignore
├── .prettierrc
├── .next.config.cjs
├── package.json
├── README.md
├── tsconfig.json
```